import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Mapa simple que permite seleccionar una coordenada con un click.
// Props:
// - coordenadas: { lat, lng } | null
// - onCoordenadasChange: function({ lat, lng })
export default function Mapa({ coordenadas, onCoordenadasChange }){
  const mapRef = useRef(null);
  const markerRef = useRef(null);

  useEffect(() => {
    // inicializar mapa una vez
    if(mapRef.current) return;
    mapRef.current = L.map('mapa-container', {
      center: [0,0],
      zoom: 2,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(mapRef.current);

    // click handler
    mapRef.current.on('click', function(e){
      const { lat, lng } = e.latlng;
      if(markerRef.current){
        markerRef.current.setLatLng(e.latlng);
      } else {
        markerRef.current = L.marker(e.latlng).addTo(mapRef.current);
      }
      if(onCoordenadasChange) onCoordenadasChange({ lat, lng });
    });

    return () => {
      if(mapRef.current) mapRef.current.remove();
      mapRef.current = null;
    };
  }, [onCoordenadasChange]);

  // si cambian las coordenadas desde afuera, mover el marcador
  useEffect(() => {
    if(!mapRef.current) return;
    if(coordenadas && coordenadas.lat != null && coordenadas.lng != null){
      const latlng = [coordenadas.lat, coordenadas.lng];
      mapRef.current.setView(latlng, 12);
      if(markerRef.current) markerRef.current.setLatLng(latlng);
      else markerRef.current = L.marker(latlng).addTo(mapRef.current);
    }
  }, [coordenadas]);

  return (
    <div style={{ width: '100%', height: '300px' }} id="mapa-container" />
  );
}
