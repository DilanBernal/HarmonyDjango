import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_BASE_URL || 'http://127.0.0.1:8000';

export default function RegisterViewModel(){
  // register accepts optional `location` field as GeoJSON Point: { type: 'Point', coordinates: [lng, lat] }
  async function register({ email, username, password, location }){
    const payload = { email, username, password };
    if(location) payload.location = location;
    const resp = await axios.post(`${API_BASE}/api/users/`, payload);
    if(resp.status !== 201) throw new Error('Registration failed');
    return resp.data;
  }

  return { register };
}
